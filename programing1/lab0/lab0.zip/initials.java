
public class initials {
  public static void main(String[] args) { 
      System.out.println("Lab 0 written by Justin McCann\n");
      System.out.println("   JJJJ DDDDDD  M     M");
      System.out.println("      J D     D MM   MM");
      System.out.println("      J D     D M M M M");
      System.out.println("      J D     D M  M  M");
      System.out.println("      J D     D M     M");
      System.out.println("J     J D     D M     M");
      System.out.println("JJJJJJJ DDDDDD  M     M");
  }

}
