package application.controller;
import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import application.Main;
import application.model.Fleet;
import application.model.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
/**
 * PersonnelController is a controller class for the
 * Personnel view of the application
 * 
 * @author Justin McCann guz232
 */
public class PersonnelController {
	//initializing some scene variables
	@FXML
    private Label welcomeLabel;
	@FXML
    private Label shipLabel;
	@FXML
    private ImageView crewImage1;
	@FXML
    private ImageView crewImage2;
	@FXML
    private ImageView crewImage3;
	@FXML
    private ImageView crewImage4;
	@FXML
    private ImageView crewImage5;
	@FXML
    private ImageView crewImage6;
	@FXML
    private ImageView crewImage7;
	@FXML
    private ImageView crewImage8;
	@FXML
    private Label rankLabel10;
	@FXML
    private Label nameLabel20;
	@FXML
    private Label rankLabel11;
    @FXML
    private Label nameLabel21;
    @FXML
    private Label rankLabel12;
    @FXML
    private Label nameLabel22;
    @FXML
    private Label rankLabel13;
    @FXML
    private Label nameLabel23;
    @FXML
    private Label rankLabel40;
    @FXML
    private Label nameLabel50;
    @FXML
    private Label rankLabel41;
    @FXML
    private Label nameLabel51;
	@FXML
    private Label rankLabel42;
    @FXML
    private Label nameLabel52;
    @FXML
    private Label rankLabel43;
    @FXML
    private Label nameLabel53;
    @FXML
    private Label errorLabel;
	/**
	 * Handle method runs when the logout
	 * button is pressed, and redirects user
	 * to the Login screen 
	 * 
	 * @param ActionEvent event
	 */
	public void handle(ActionEvent event) {
		// Redirect user back to login
		try {
			Parent root = FXMLLoader.load(getClass().getResource("../view/Login.fxml"));
			Main.stage.setScene(new Scene(root, 800, 600));
			Main.stage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	/**
	 * Loads pictures and text related to the
	 * user that has logged in
	 * 
	 * @param User
	 */
	public void loadScene(User currUser) {
		//generate fleet to find starship
		Fleet fleet = new Fleet("Star Fleet");
		try {
			fleet = fleet.fleetGenerator();
		} catch (IOException e) {
			e.printStackTrace();
		}
		//search through the fleet to find starship with user
		for (int i = 0; i < fleet.getfStarships().size(); i++ ) {
			for ( int j = 0; j < fleet.getfStarships().get(i).getShipCrew().size(); j++ ) {
				if (fleet.getfStarships().get(i).getShipCrew().get(j).getcName().toLowerCase().contains(currUser.getUserName())) {
					currUser.setShipCrew(fleet.getfStarships().get(i).getShipCrew());
					currUser.setStarship(fleet.getfStarships().get(i));
					break;
				}
			}
			if (currUser.getStarship() != null) {
				break;
			}
		}
		//initialize string variables for image path
		String imagePath0 = "";
		String imagePath1 = "";
		String imagePath2 = "";
		String imagePath3 = "";
		String imagePath4 = "";
		String imagePath5 = "";
		String imagePath6 = "";
		String imagePath7 = "";
		//if a starship was found and the starship has a crew then 
		//initialize text information and pictures for Personnel
		if (currUser.getStarship() != null) {
			if( currUser.getStarship().getShipCrew().size() == 8 ) {
				welcomeLabel.setText("Welcome, Captain " + currUser.getUserName().substring( 0, 1).toUpperCase() + currUser.getUserName().substring(1) );
				shipLabel.setText(currUser.getStarship().getShipName() + " " + currUser.getStarship().getsRegistry());
				rankLabel10.setText(currUser.getShipCrew().get(0).getcPosition());
				nameLabel20.setText(currUser.getShipCrew().get(0).getcRank() + " " + currUser.getShipCrew().get(0).getcName());
				rankLabel11.setText(currUser.getShipCrew().get(1).getcPosition());
				nameLabel21.setText(currUser.getShipCrew().get(1).getcRank() + " " + currUser.getShipCrew().get(1).getcName());
				rankLabel12.setText(currUser.getShipCrew().get(2).getcPosition());
				nameLabel22.setText(currUser.getShipCrew().get(2).getcRank() + " " + currUser.getShipCrew().get(2).getcName());
				rankLabel13.setText(currUser.getShipCrew().get(3).getcPosition());
				nameLabel23.setText(currUser.getShipCrew().get(3).getcRank() + " " + currUser.getShipCrew().get(3).getcName());
				rankLabel40.setText(currUser.getShipCrew().get(4).getcPosition());
				nameLabel50.setText(currUser.getShipCrew().get(4).getcRank() + " " + currUser.getShipCrew().get(4).getcName());
				rankLabel41.setText(currUser.getShipCrew().get(5).getcPosition());
				nameLabel51.setText(currUser.getShipCrew().get(5).getcRank() + " " + currUser.getShipCrew().get(5).getcName());
				rankLabel42.setText(currUser.getShipCrew().get(6).getcPosition());
				nameLabel52.setText(currUser.getShipCrew().get(6).getcRank() + " " + currUser.getShipCrew().get(6).getcName());
				rankLabel43.setText(currUser.getShipCrew().get(7).getcPosition());
				nameLabel53.setText(currUser.getShipCrew().get(7).getcRank() + " " + currUser.getShipCrew().get(7).getcName());
				imagePath0 = "images/" + currUser.getShipCrew().get(0).getLastNameLowerCase() + ".jpg";
				imagePath1 = "images/" + currUser.getShipCrew().get(1).getLastNameLowerCase() + ".jpg";
				imagePath2 = "images/" + currUser.getShipCrew().get(2).getLastNameLowerCase() + ".jpg";
				imagePath3 = "images/" + currUser.getShipCrew().get(3).getLastNameLowerCase() + ".jpg";
				imagePath4 = "images/" + currUser.getShipCrew().get(4).getLastNameLowerCase() + ".jpg";
				imagePath5 = "images/" + currUser.getShipCrew().get(5).getLastNameLowerCase() + ".jpg";
				imagePath6 = "images/" + currUser.getShipCrew().get(6).getLastNameLowerCase() + ".jpg";
				imagePath7 = "images/" + currUser.getShipCrew().get(7).getLastNameLowerCase() + ".jpg";
				try {
					crewImage1.setImage(getImage(imagePath0));
					crewImage2.setImage(getImage(imagePath1));
					crewImage3.setImage(getImage(imagePath2));
					crewImage4.setImage(getImage(imagePath3));
					crewImage5.setImage(getImage(imagePath4));
					crewImage6.setImage(getImage(imagePath5));
					crewImage7.setImage(getImage(imagePath6));
					crewImage8.setImage(getImage(imagePath7));
				} catch (MalformedURLException e) {
					e.printStackTrace();
				}
			}
		} else {
			//if starship or crew was not found then error is displayed
			errorLabel.setText("ERROR: Crew for Captain " + currUser.getUserName().substring( 0, 1).toUpperCase() + currUser.getUserName().substring(1) + " has not been added to the database");
		}
	}
	/**
	 * creates image object for ImageView
	 * returns Image object
	 * 
	 * @param String
	 * 
	 */
	public Image getImage(String imagePath) throws MalformedURLException {
		//creates file for Image
		File imageFile = new File(imagePath);
		//creates image from file URL
		Image image1 = new Image(imageFile.toURI().toURL().toExternalForm());
		return image1;
	}
	
}
