package application.controller;
import application.Main;
import application.model.User;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
/**
 * MainController is a controller class for the
 * main view of the application
 * 
 * @author Justin McCann guz232
 */
public class LoginController {
	//initializing some scene variables
	@FXML 
	private PasswordField passField;

    @FXML
    private TextField userField;
    
    @FXML
    private Label errorLabel;
	/**
	 * Handle method runs when the button 
	 * is pressed in the main view 
	 * validates username and passphrase
	 * then redirects user to Personnel
	 * 
	 * @param ActionEvent event
	 */
	public void handle(ActionEvent event) {
		//gets text from text/password field and validates
		String user = userField.getText();
		String pass = passField.getText();
		User currentUser = null;
		currentUser = User.validate(user, pass);
		// Redirect user to next view if a user is returned from validate - personnel
		if( currentUser != null ) {
			try {
				FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/Personnel.fxml"));	
				Parent root = (Parent) loader.load();
				PersonnelController perCont = loader.getController();
				perCont.loadScene(currentUser);
				Main.stage.setScene(new Scene(root, 800, 600));
				Main.stage.show();
			} catch(Exception e) {
				e.printStackTrace();
			}
		} else {
			//Displays error message if user of passphrase is wrong
			errorLabel.setText("ERROR: Incorrect User or Passphrase");
		}
	}
	
}
