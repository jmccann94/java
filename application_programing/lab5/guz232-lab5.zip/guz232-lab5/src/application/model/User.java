package application.model;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;
/**
 * User is a class containing the UserName, and
 * the Passphrase entered by the user
 * 
 * @author Justin McCann guz232
 */
public class User {
	//Class Variables
	private String userName;
	private String passWord;
	private Starship starship;
	private ArrayList<CrewMember> shipCrew;
	//constructor
	public User(String userName, String passWord) {
		this.userName = userName;
		this.passWord = passWord;
		this.starship = null;
		this.shipCrew = new ArrayList<CrewMember>();
	}
	//getters, setters, and adders
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassWord() {
		return passWord;
	}
	public void setPassWord(String passWord) {
		this.passWord = passWord;
	}
	
	public Starship getStarship() {
		return starship;
	}

	public void setStarship(Starship starship) {
		this.starship = starship;
	}
	
	public ArrayList<CrewMember> getShipCrew() {
		return shipCrew;
	}

	public void setShipCrew(ArrayList<CrewMember> shipCrew) {
		this.shipCrew = shipCrew;
	}
	/**
	 * Validates user info 
	 * 
	 * 
	 * @param String String
	 */
	public static User validate(String user, String pass) {
		User ret = null;
		
		//initialize scanner
		Scanner scan;
		try {
			scan = new Scanner (  new File("data/users.csv")  );
			//scan file, delimiting at commas and verifying user and passphrase
			while( scan.hasNextLine() ) {
				String line = scan.nextLine();
				String[] tokens = line.split(",");
				if( user.equals(tokens[0]) ) {
					if( pass.equals(tokens[1]) ) {
						ret = new User(tokens[0], tokens[1]);
					}
				}
			}
			//close scanner
			scan.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return ret;
	}
	
}
