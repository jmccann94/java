package application.model;
import java.util.*;
/**
 * Starship is a class containing the name, class,
 * registry, and list of crew members of a starship
 * 
 * @author Justin McCann guz232
 */
public class Starship {
	
	//Class variables
	private String shipName;
	private String sRegistry;
	private String shipClass;
	private ArrayList<CrewMember> shipCrew;
	
	//Constructor
	public Starship(String shipName, String sRegistry, String shipClass) {
		this.shipName = shipName;
		this.sRegistry = sRegistry;
		this.shipClass = shipClass;
		this.shipCrew = new ArrayList<CrewMember>();
	}

	//toString
	public String toString() {
		String ret = "   " + shipName + " [" + sRegistry + "], Class: " + shipClass;
		ret += "  Crew: " + shipCrew.size() + "\n";
		for( int i = 0; i<shipCrew.size() ; i++ ) {
			ret += shipCrew.get(i).toString();
		}
		ret += "\n";
		return ret;
	}

	//Getters, Setters and Adders
	public String getShipName() {
		return shipName;
	}

	public void setShipName(String shipName) {
		this.shipName = shipName;
	}

	public String getsRegistry() {
		return sRegistry;
	}

	public void setsRegistry(String sRegistry) {
		this.sRegistry = sRegistry;
	}

	public String getShipClass() {
		return shipClass;
	}

	public void setShipClass(String shipClass) {
		this.shipClass = shipClass;
	}

	public ArrayList<CrewMember> getShipCrew() {
		return shipCrew;
	}

	public void setShipCrew(ArrayList<CrewMember> shipCrew) {
		this.shipCrew = shipCrew;
	}
	
	public void addCrewMember(CrewMember newCrew ) {
		this.shipCrew.add(newCrew);
	}
	
}
