package application.model;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;
import java.io.FileWriter;
/**
 * Park is a Java class containing the name of a park and an array
 * of zones to be stored within the park. 
 * 
 * @author Justin McCann guz232
 *
 */
public class Park {
	
	//Class varibles
	private String parkName;
	private Map<Zone,ArrayList<Dinosaur>> parkMap;
	
	//Constructor 
	public Park (String parkName) {
		this.parkName = parkName;
		this.parkMap = new HashMap<Zone,ArrayList<Dinosaur>>();
	}
	
	//toString method to print out the park and all its zones and dinos
	public String toString() {
		String ret ="Welcome to " + parkName + "!\n";
		ret += "-------------------------\n";
		for (Entry<Zone, ArrayList<Dinosaur>> ee : parkMap.entrySet()) {
			Zone zone = ee.getKey();
			ret += this.parkMap.get(zone).toString();
		}
		return ret;
	}
	
	/**
	 * 
	 * @param zoneCode
	 * @return String
	 */
	public String printZone(String zoneCode) {
		String ret = "";
		for (Entry<Zone, ArrayList<Dinosaur>> ee : parkMap.entrySet()) {
			Zone key = ee.getKey();
			if (key.getZoneCode().equals(zoneCode)) {
				break;
			}
		}
		return ret;
	}
	
	//getters and setters
	public String getParkName() {
		return this.parkName;
	}
	
	public void setParkName(String parkName) {
		this.parkName = parkName;
	}

	public Map<Zone, ArrayList<Dinosaur>> getParkMap() {
		return parkMap;
	}

	public void setParkMap(Map<Zone, ArrayList<Dinosaur>> parkMap) {
		this.parkMap = parkMap;
	}
	
	public int getNumberOfZones() {
		int ret = parkMap.size();
		return ret;
	}
	
	/**
	 * Creates a park and loads from files in /data
	 * 
	 * @return String
	 */
	public static Park parkGen() {
		Park ret = new Park("Jurrasic Park");
		try {
			ret.loadZones("data/zones.csv");
			ret.loadDinosaurs("data/dinos.csv");
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return ret;
	}
	
	/**
	 * Reads from zone file and adds them to the park
	 * takes in the file name, and reads from it
	 * 
	 * throws exception if file is not found
	 * @param fileName
	 * @throws IOException
	 */
	public void loadZones(String fileName) throws IOException {
		//open the file for reading
		Scanner scan = new Scanner ( new File(fileName) );
		
		//read in, line by line, creating zones
		while ( scan.hasNextLine() ) {
			String line = scan.nextLine();
			String[] tokens = line.split(",");
			Zone tmp = null;
			tmp = new Zone(tokens[0], tokens[1], tokens[2]);
			parkMap.putIfAbsent(tmp, new ArrayList<Dinosaur>());
		}
		//close file
		scan.close();
	
	}
	
	
	/**
	 * Reads from dino file and adds them to zones
	 * takes in file name 
	 * 
	 * throws exception if file is not found
	 * @param fileName
	 * @throws IOException
	 */
	public void loadDinosaurs(String fileName) throws IOException {
		//open the file for reading
		Scanner scan = new Scanner ( new File(fileName) );
		
		//read in, line by line, creating dinosaurs, adding to zones
		while( scan.hasNextLine() ) {
			String line = scan.nextLine();
			String[] tokens = line.split(",");
			boolean veg;
			if (tokens[2].equals("true")) {
				veg = true;
			}else {
				veg = false;
			}
			Dinosaur tmp = new Dinosaur(tokens[1], tokens[0], veg, tokens[3]);
			for (Entry<Zone, ArrayList<Dinosaur>> ee : parkMap.entrySet()) {
				Zone key = ee.getKey();
				if (key.getZoneCode().equals(tokens[3])) {
					parkMap.get(key).add(tmp);
				}
			}
		}
		//close file
		scan.close();

	}
	
	/**
	 * Relocates dinosaur to a new zone
	 * 
	 * takes in a dinosaurs name and a new zonecode
	 * loops through zones to find dinosaur
	 * saves dinosaurs info, removes it from old zone 
	 * then adds it to new zone
	 * 
	 * @param dinoName
	 * @param newZoneCode
	 */
	public void relocate(String dinoName, String newZoneCode) {
		Dinosaur dino = null;
		Zone newZone = null;
		
		for (Entry<Zone, ArrayList<Dinosaur>> ee : parkMap.entrySet()) {
			Zone zone = ee.getKey();
			for (int i = 0; i < parkMap.get(zone).size(); i++) {
				if (parkMap.get(zone).get(i).getDinoName().equals(dinoName)) {
					dino = parkMap.get(zone).get(i);
					parkMap.get(zone).remove(dino);
					break;
				}
			}
			if (zone.getZoneCode().equals(newZoneCode)) {
				newZone = zone;
			}
		}
		dino.setZoneCode(newZoneCode);
		this.parkMap.get(newZone).add(dino);
	}
	
	/**
	 * adds dinosaur to zonecode in dinosaur
	 * 
	 * @param dino
	 */
	public void addDinosaur(Dinosaur dino) {
		
		for (Entry<Zone, ArrayList<Dinosaur>> ee : parkMap.entrySet()) {
			Zone zone = ee.getKey();
			if (zone.getZoneCode().equals(dino.getZoneCode())) {
				parkMap.get(zone).add(dino);
			}
		}
	}
	
	/**
	 * 
	 * @param zoneCode
	 * @return
	 */
	public int getNumberOfDinosaursInZone(String zoneCode) {
		int ret = 0;
		for (Entry<Zone, ArrayList<Dinosaur>> ee : parkMap.entrySet()) {
			if ( ee.getKey().getZoneCode().equals(zoneCode) ) {
				ret += ee.getValue().size();
			}
		}
		
		return ret;
	}
	
	/**
	 * Save zone and dino info to files
	 * overwrites old data files with any new info
	 * 
	 * throws exception if files are not found
	 * @throws IOException
	 */
	public void save() throws IOException {
		//open the file for writing
		FileWriter writer1 = new FileWriter( new File("data/zones.csv") );
		
		//write out line by line
		for (Entry<Zone, ArrayList<Dinosaur>> ee : parkMap.entrySet()) {
			Zone zone = ee.getKey();
			writer1.write(zone.getZoneName() + "," + zone.getCriticalSafetyRating() + "," + zone.getZoneCode() + "\n");
		}
		
		//close the file
		writer1.close();
		
		//open the file for writing
		FileWriter writer2 = new FileWriter( new File("data/dinos.csv") );
		//write out line by line
		for (Entry<Zone, ArrayList<Dinosaur>> ee : parkMap.entrySet()) {
			Zone zone = ee.getKey();
			for (int i = 0; i < this.parkMap.get(zone).size(); i++) {
				Dinosaur tmpD = this.parkMap.get(zone).get(i);
				writer2.write(tmpD.getDinoName() + "," + tmpD.getDinoType() + "," + tmpD.getVegetarian() + "," + tmpD.getZoneCode() + "\n");
			}
		}
		
		//close the file
		writer2.close();
	}

}
