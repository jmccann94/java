package application.model;
/**
 * Zone is a Java class containing the name of a Zone, an array 
 * of dinosaur objects, and a critical safety rating
 * 
 * @author Justin McCann guz232
 *
 */

public class Zone {
	
	//class variables
	private String zoneName;
	private String zoneCode;
	private String criticalSafetyRating;
	
	//constructor
	public Zone (String zoneName, String csr, String zoneCode) {
		this.zoneName = zoneName;
		this.criticalSafetyRating = csr;
		this.zoneCode = zoneCode;
	}
	
	//toString that list out all the dinos in the zone
	public String toString() {
		String ret =zoneCode + ": " + zoneName + " Zone (" + criticalSafetyRating + " risk):\n";
		return ret;
	}

	//getters and setters
	public String getZoneName() {
		return this.zoneName;
	}
	
	public String getCriticalSafetyRating() {
		return criticalSafetyRating;
	}
	
	public String getZoneCode() {
		return zoneCode;
	}
	
	public void setZoneName(String zoneName) {
		this.zoneName = zoneName;
	}
	
	public void setCriticalSafetyRating(String criticalSafetyRating) {
		this.criticalSafetyRating = criticalSafetyRating;
	}
	
	public void setZoneCode(String zoneCode) {
		this.zoneCode = zoneCode;
	}
	
}
