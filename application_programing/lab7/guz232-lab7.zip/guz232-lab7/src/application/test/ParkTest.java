package application.test;
import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.Map.Entry;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import application.model.Dinosaur;
import application.model.Park;
import application.model.Zone;
/**
 * 
 * @author Justin McCann
 *
 */
public class ParkTest {
	
	Park testPark;

	@Before
	public final void setUpBeforeClass() throws Exception {
		testPark = new Park("Test Park");
		testPark.loadZones("data/zones.csv");
	}

	
	/**
	 * Test if after a dino is added number of dinos increases to 1
	 */
	public void testGetNumberOfDinosaursInZone() {
		// Assume there is a park with zones
		
		// Check: park has 7 zones
		int number = testPark.getNumberOfZones();
		assert( number==7 ) : "Invalid park object or assumption! Number of Zones: " + number;
		
		// Check: all zones have no dinosaurs
		number = 0;
		for (Entry<Zone, ArrayList<Dinosaur>> ee : testPark.getParkMap().entrySet()) {
			number += ee.getValue().size();
		}
		assert( number==0 ) : "Invalid Park object or Zone objects: Number of Dinosaurs: " + number;
		
		// Good Behavior : Add Dinosaur to a zone (X)
		Dinosaur testDino = new Dinosaur("Testasaur", "Test", false, "X");
		testPark.addDinosaur(testDino);
		
		// Check : All zones should have a total of 0 except zone X should have 1
		// so we check each zone for there number of dinos
		int numberinX = 0;
		number = 0;
		for (Entry<Zone, ArrayList<Dinosaur>> ee : testPark.getParkMap().entrySet()) {
			if ( ee.getKey().getZoneCode().equals("X") ) {
				numberinX += testPark.getNumberOfDinosaursInZone(ee.getKey().getZoneCode());
			}else {
				number += testPark.getNumberOfDinosaursInZone(ee.getKey().getZoneCode());
			}
		}
		assert( (number == 0) & (numberinX == 1) ) : "Dinosaur was not added into correct zone or at all! Number in other"
				+ " zones: " + number + " Number in X: " + numberinX;
	}
	
	/**
	 * Test that a dinosaur was added with correct info
	 */
	@Test
	public void testAddDinosaur() {
		// Assume there is a park
		
		// Check: park has 7 zones
		int number = testPark.getNumberOfZones();
		assert( number==7 ) : "Invalid park object or assumption! Number of Zones: " + number;
		
		// Check: All zones have no dinosaurs
		number = 0;
		for (Entry<Zone, ArrayList<Dinosaur>> ee : testPark.getParkMap().entrySet()) {
			number += ee.getValue().size();
		}
		assert( number==0 ) : "Invalid Park object or Zone objects: Number of Dinosaurs: " + number;
		
		// Good Behavior: Add dinosaur with just dino info
		Dinosaur testDino = new Dinosaur("Testasaur", "Test", false, "X");
		testPark.addDinosaur(testDino);
		
		// Check: Zone has one dinosaur
		Zone zone = null;
		for (Entry<Zone, ArrayList<Dinosaur>> ee : testPark.getParkMap().entrySet()) {
			zone = ee.getKey();
			if ( zone.getZoneCode().equals("X")) {
				break;
			}
		}
		number = testPark.getParkMap().get(zone).size();
		assert( number==1 ) : "New Dinosaur was not added! Number of Dinosaurs: " + number;
		
		// Check to see if Dino was added with correct name
		String name = testPark.getParkMap().get(zone).get(0).getDinoName();
		assert( name.equals("Test") ) : "Dino was not named correctly! Name: " + name;
		
		// Check to see if Dino was added with correct Type
		String type = testPark.getParkMap().get(zone).get(0).getDinoType();
		assert( type.equals("Testasaur")) : "Dino was not added with correct type! Type: " + type;
		
		// Check to see if Dino was added with correct diet
		boolean diet = testPark.getParkMap().get(zone).get(0).getVegetarian();
		assert( diet==false ) : "Dino was added with incorrect diet! Diet: " + String.valueOf(diet);
		
	}
	
	/**
	 * Test that the relocate function moves dinosaur to new zone,
	 * and that the new zone is correct, and the old zone no longer
	 * has the dino
	 */
	public void testRelocateDinosaur() {
		// Assume there is a park
		
		// Check: park has 7 zones
		int number = testPark.getNumberOfZones();
		assert( number==7 ) : "Invalid park object or assumption! Number of Zones: " + number;
		
		// Check: All zones have no dinosaurs
		number = 0;
		for (Entry<Zone, ArrayList<Dinosaur>> ee : testPark.getParkMap().entrySet()) {
			number += ee.getValue().size();
		}
		assert( number==0 ) : "Invalid Park object or Zone objects: Number of Dinosaurs: " + number;
		
		// Good Behavior: Add dinosaur with just dino info
		Dinosaur testDino = new Dinosaur("Testasaur", "Test", false, "X");
		testPark.addDinosaur(testDino);
		
		// Check : Zone has one dinosaur
		Zone zone = null;
		for (Entry<Zone, ArrayList<Dinosaur>> ee : testPark.getParkMap().entrySet()) {
			zone = ee.getKey();
			if ( zone.getZoneCode().equals("X")) {
				break;
			}
		}
		number = testPark.getParkMap().get(zone).size();
		assert( number==1 ) : "New Dinosaur was not added! Number of Dinosaurs: " + number;
		
		// Good Behavior : relocate from X to TY
		testPark.relocate( "Test", "TY" );
		
		// Check : Zone X has 0 dinos, and Zone TY has 1
		int numberinX = 0;
		int numberinTY = 0;
		number = 0;
		for (Entry<Zone, ArrayList<Dinosaur>> ee : testPark.getParkMap().entrySet()) {
			if ( ee.getKey().getZoneCode().equals("X") ) {
				numberinX += ee.getValue().size();
			} else if( ee.getKey().getZoneCode().contentEquals("TY") ) {
				numberinTY += ee.getValue().size();
			} else {
				number += ee.getValue().size();
			}
		}
		assert( number==0 ) : "Dinosaur was relocated to wrong zone";
		assert( numberinX==0 ) : "Dinosaur was not removed from orignal zone";
		assert( numberinTY==1 ) : "Dinosaur was not inserted into new zone";
		
		assert( (number == 0) & (numberinX == 1) ) : "Dinosaur was not added into correct zone or at all! Number in other"
				+ " zones: " + number + " Number in X: " + numberinX;
		
	}

}
