package application.controller;

import application.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

public class MainController {

	@FXML
    private Button zoneG, zoneD, zoneTR, zoneX, zoneB, zoneR, zoneTY;
	
	public void handleG(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/Zone.fxml"));	
			Parent root = (Parent) loader.load();
			ZoneController zoneCont = loader.getController();
			zoneCont.loadScene("G");
			Main.stage.setScene(new Scene(root, 800, 600));
			Main.stage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void handleD(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/Zone.fxml"));	
			Parent root = (Parent) loader.load();
			ZoneController zoneCont = loader.getController();
			zoneCont.loadScene("D");
			Main.stage.setScene(new Scene(root, 800, 600));
			Main.stage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void handleTR(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/Zone.fxml"));	
			Parent root = (Parent) loader.load();
			ZoneController zoneCont = loader.getController();
			zoneCont.loadScene("TR");
			Main.stage.setScene(new Scene(root, 800, 600));
			Main.stage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
		
	}
	
	public void handleX(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/Zone.fxml"));	
			Parent root = (Parent) loader.load();
			ZoneController zoneCont = loader.getController();
			zoneCont.loadScene("X");
			Main.stage.setScene(new Scene(root, 800, 600));
			Main.stage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void handleB(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/Zone.fxml"));	
			Parent root = (Parent) loader.load();
			ZoneController zoneCont = loader.getController();
			zoneCont.loadScene("B");
			Main.stage.setScene(new Scene(root, 800, 600));
			Main.stage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void handleR(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/Zone.fxml"));	
			Parent root = (Parent) loader.load();
			ZoneController zoneCont = loader.getController();
			zoneCont.loadScene("R");
			Main.stage.setScene(new Scene(root, 800, 600));
			Main.stage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void handleTY(ActionEvent event) {
		try {
			FXMLLoader loader = new FXMLLoader(getClass().getResource("../view/Zone.fxml"));	
			Parent root = (Parent) loader.load();
			ZoneController zoneCont = loader.getController();
			zoneCont.loadScene("TY");
			Main.stage.setScene(new Scene(root, 800, 600));
			Main.stage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
		
	}

	
}
