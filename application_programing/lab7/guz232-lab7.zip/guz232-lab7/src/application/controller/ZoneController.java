package application.controller;

import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;
import application.Main;
import application.model.Dinosaur;
import application.model.Park;
import application.model.Zone;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

public class ZoneController {
	@FXML
    private TextField newNameText, relZoneText, relNameText, newTypeText;

    @FXML
    private RadioButton carnYes, carnNo;

    @FXML
    private Label zoneLabel, countLabel, riskLabel, relNotify, newNotify;

    @FXML
    private Button addB, homeB, relButton;

    @FXML
    private ListView<String> dinoList;

    /**
     * 
     * @param event
     */
    public void handleExit(ActionEvent event) {
    	try {
			Parent root = FXMLLoader.load(getClass().getResource("../view/Main.fxml"));
			Main.stage.setScene(new Scene(root, 800, 600));
			Main.stage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
    }
    /**
     * 
     * @param event
     */
    public void handleAdd(ActionEvent event) {
    	Park park = Park.parkGen();
    	String zoneCode = "";
    	String zoneCodeLabel = zoneLabel.getText();
    	String[] labelToke = zoneCodeLabel.split(" ");
    	
    	if(labelToke[1].length() == 4) {
    		zoneCode = labelToke[1].substring(1, 3);
    	}else {
    		zoneCode = labelToke[1].substring(1, 2);
    	}
    	boolean veg = carnNo.isSelected();
    	
    	Dinosaur temp = new Dinosaur(newTypeText.getText(), newNameText.getText(), veg, zoneCode);
    	
    	park.addDinosaur(temp);
    	
    	newNotify.setText(temp.getDinoName() + " was successfully added.");
    	
    	try {
			park.save();
		} catch (IOException e) {
			e.printStackTrace();
		}
    	
    	loadScene(zoneCode);
    }
    /**
     * 
     * @param event
     */
    public void handleRel(ActionEvent event) {
    	Park park = Park.parkGen();
    	String zoneCode = "";
    	String zoneCodeLabel = zoneLabel.getText();
    	String[] labelToke = zoneCodeLabel.split(" ");
    	
    	if(labelToke[1].length() == 4) {
    		zoneCode = labelToke[1].substring(1, 3);
    	}else {
    		zoneCode = labelToke[1].substring(1, 2);
    	}
    	
    	park.relocate(relNameText.getText(), relZoneText.getText());
    	relNotify.setText(relNameText.getText() + " was successfully relocated to " + relZoneText.getText());
    	try {
			park.save();
		} catch (IOException e) {
			e.printStackTrace();
		}
    	loadScene(zoneCode);
    }
    
    /**
     * 
     * @param zoneCode
     */
	public void loadScene(String zoneCode) {
		Park park = Park.parkGen();
		Zone zone = null;
		
		for (Entry<Zone, ArrayList<Dinosaur>> ee : park.getParkMap().entrySet()) {
			zone = ee.getKey();
			if (zone.getZoneCode().equals(zoneCode)) {
				break;
			}
		}
		
		zoneLabel.setText(zone.getZoneName() + " (" + zoneCode + ")");
		countLabel.setText(Integer.toString(park.getParkMap().get(zone).size()));
		riskLabel.setText(zone.getCriticalSafetyRating());
		ObservableList<String> list = FXCollections.observableArrayList();
		String temp = "";
		
		for ( int i = 0; i < park.getParkMap().get(zone).size(); i++) {
			temp = park.getParkMap().get(zone).get(i).toString();
			list.add(temp);
		}
		dinoList.setItems( list );
	}

}
