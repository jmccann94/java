package application.model;
/*
 * CrewMember is a class containing the name, position,
 * rank, and species of a crew member
 * 
 * @author Justin McCann guz232
 */
public class CrewMember {
	
	//class variables
	private String cName;
	private String cPosition;
	private String cRank;
	private String cSpecies;
	
	//constructor
	public CrewMember (String cName, String cPosition, String cRank, String cSpecies) {
		this.cName = cName;
		this.cPosition = cPosition;
		this.cRank = cRank;
		this.cSpecies = cSpecies;
	}

	//toString
	public String toString() {
		String ret = "\t- ";
		ret+= cName + ", " + cPosition + " (" + cSpecies + ")\n";
		return ret;
	}

	//Getters and Setters
	public String getcName() {
		return cName;
	}

	public void setcName(String cName) {
		this.cName = cName;
	}

	public String getcPosition() {
		return cPosition;
	}

	public void setcPosition(String cPosition) {
		this.cPosition = cPosition;
	}

	public String getcRank() {
		return cRank;
	}

	public void setcRank(String cRank) {
		this.cRank = cRank;
	}

	public String getcSpecies() {
		return cSpecies;
	}

	public void setcSpecies(String cSpecies) {
		this.cSpecies = cSpecies;
	}
	
}
