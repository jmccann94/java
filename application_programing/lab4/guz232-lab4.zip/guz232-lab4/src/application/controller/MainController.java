package application.controller;
import java.io.IOException;
import application.model.Fleet;
import application.model.Starship;
import java.util.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
/*
 * MainController is a controller class for the
 * main view of the application
 * 
 * @author Justin McCann guz232
 */
public class MainController {
	//initializing some scene variables
	@FXML 
	TextArea resultTextArea;
	@FXML
	TextField searchTextField;
	/*
	 * Handle method runs when the button 
	 * is pressed in the main view 
	 * 
	 * @param ActionEvent event
	 */
	public void handle(ActionEvent event) {
		//initialize variables
		String inputS = searchTextField.getText();
		ArrayList<Starship> result = new ArrayList<Starship>(); 
		Fleet fleet = new Fleet("Federation of Planets");
		//load fleet contents from data 
		try {
			fleet = fleet.fleetGenerator();
		}catch( IOException e ) {
			System.out.println( "Error loading the file - please check its location." );
			e.printStackTrace();
		}
		//searching for the ship name within the fleet
		result = fleet.getStarshipsByName( inputS );
		//new fleet to add the results in
		Fleet printfleet = new Fleet("");
		printfleet.setfStarships(result);
		//checking if the ArrayList is empty
		if( result.isEmpty() ) {
			resultTextArea.setText( "Starship was not found!");
		}else {
			resultTextArea.setText( printfleet.toString() );
		}
		
	}
	
}
